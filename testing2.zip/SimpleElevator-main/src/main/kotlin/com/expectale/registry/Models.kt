package com.expectale.registry

import com.expectale.SimpleElevator
import xyz.xenondevs.nova.addon.registry.ItemRegistry
import xyz.xenondevs.nova.initialize.Init
import xyz.xenondevs.nova.initialize.InitStage
import xyz.xenondevs.nova.world.item.NovaItem

@Init(stage = InitStage.PRE_PACK)
object Models : ItemRegistry by SimpleElevator.registry {
    
    val BLACK_ELEVATOR = modelItem("black_elevator")
    val BLUE_ELEVATOR = modelItem("blue_elevator")
    val BROWN_ELEVATOR = modelItem("brown_elevator")
    val CYAN_ELEVATOR = modelItem("cyan_elevator")
    val GRAY_ELEVATOR = modelItem("gray_elevator")
    val GREEN_ELEVATOR = modelItem("green_elevator")
    val LIGHT_BLUE_ELEVATOR = modelItem("light_blue_elevator")
    val LIGHT_GRAY_ELEVATOR = modelItem("light_gray_elevator")
    val LIME_ELEVATOR = modelItem("lime_elevator")
    val MAGENTA_ELEVATOR = modelItem("magenta_elevator")
    val ORANGE_ELEVATOR = modelItem("orange_elevator")
    val PINK_ELEVATOR = modelItem("pink_elevator")
    val PURPLE_ELEVATOR = modelItem("purple_elevator")
    val RED_ELEVATOR = modelItem("red_elevator")
    val WHITE_ELEVATOR = modelItem("white_elevator")
    val YELLOW_ELEVATOR = modelItem("yellow_elevator")
    
    private fun modelItem(name: String): NovaItem = item("model/$name") {
        hidden(true)
        modelDefinition { model = buildModel { getModel("block/$name") } }
    }
}